package paquete1;

public class Clase1 {
    public String atributoPublico = "Valor atributo publico";
    
    public Clase1(){
        System.out.println("Constructor Publico");
    } 
    
    public void metodoPublico(){
        System.out.println("Metodo publico");
    }
}
